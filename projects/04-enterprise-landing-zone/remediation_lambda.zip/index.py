import boto3

s3 = boto3.client('s3')

def handler(event, context):
    # EventBridgeから渡されるCloudTrailのログ情報から、変更されたバケット名を抽出
    detail = event.get('detail', {})
    bucket_name = detail.get('requestParameters', {}).get('bucketName')
    
    if not bucket_name:
        return "No bucket name found."
        
    print(f"警告: {bucket_name} のパブリックアクセス設定が変更されました。自動修復を開始します。")
    
    # バケットのパブリックアクセスを強制的に「すべてブロック（True）」に戻す
    s3.put_public_access_block(
        Bucket=bucket_name,
        PublicAccessBlockConfiguration={
            'BlockPublicAcls': True,
            'IgnorePublicAcls': True,
            'BlockPublicPolicy': True,
            'RestrictPublicBuckets': True
        }
    )
    return f"修復完了: {bucket_name} を安全な状態に戻しました。"
